-- Project: The Kopi Tide Sales & Weather Analysis
-- Tool: Google BigQuery

-- Note: Replace `case-study-490607` with your own BigQuery project ID

-- Step 3: Join summary with weather data

SELECT
  summary_all.*,
  weather_all.rainfall_total_mm,
  weather_all.mean_temp_deg
FROM thekopitide_2024.summary_all
JOIN singapore_weather_2024.weather_all
ON summary_all.date = weather_all.date;