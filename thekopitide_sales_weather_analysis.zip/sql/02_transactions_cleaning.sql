-- Project: The Kopi Tide Sales & Weather Analysis
-- Tool: Google BigQuery

-- Note: Replace `case-study-490607` with your own BigQuery project ID

-- Step 2: Clean transactions data

-- Extract date & time
SELECT 
  DATE(datetime) AS date,
  TIME(datetime) AS time
FROM `case-study-490607.thekopitide_2024.transactions_all`;

-- Remove duplicates
CREATE OR REPLACE TABLE thekopitide_2024.transactions_clean AS
SELECT DISTINCT *
FROM `case-study-490607.thekopitide_2024.transactions_all`;

-- Identify duplicates (for validation)
SELECT *
FROM `case-study-490607.thekopitide_2024.transactions_all`
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY transaction_id, date, time, store_id, store_name, product_id, quantity,
               CAST(unit_price AS STRING), CAST(total_amount AS STRING), payment_method
) > 1;