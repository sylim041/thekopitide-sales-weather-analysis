-- Project: The Kopi Tide Sales & Weather Analysis
-- Tool: Google BigQuery

-- Note: Replace `case-study-490607` with your own BigQuery project ID
-- Step 6: Menu analysis

CREATE VIEW thekopitide_2024.analysis_menu AS
SELECT
  menu.*,
  transactions_all.quantity
FROM thekopitide_2024.menu
LEFT JOIN thekopitide_2024.transactions_all
ON menu.product_id = transactions_all.product_id;

-- Top products
SELECT
  product_id,
  product_name,
  SUM(quantity) AS total_sold
FROM thekopitide_2024.analysis_menu
GROUP BY product_id, product_name
ORDER BY total_sold DESC;