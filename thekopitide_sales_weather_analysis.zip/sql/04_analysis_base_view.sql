-- Project: The Kopi Tide Sales & Weather Analysis
-- Tool: Google BigQuery

-- Note: Replace `case-study-490607` with your own BigQuery project ID
-- Step 4: Create base view for analysis

CREATE VIEW thekopitide_2024.analysis_base AS
SELECT
  summary_all.*,

  -- Assign rainfall based on store
  CASE
    WHEN summary_all.store_id = 'S001' THEN weather_central.rainfall_total_mm
    WHEN summary_all.store_id = 'S002' THEN weather_west.rainfall_total_mm
  END AS rainfall,

  -- Assign temperature (west only)
  CASE
    WHEN summary_all.store_id = 'S002' THEN weather_west.mean_temp_deg
  END AS mean_temperature

FROM thekopitide_2024.summary_all

LEFT JOIN singapore_weather_2024.weather_central
  ON summary_all.date = weather_central.date

LEFT JOIN singapore_weather_2024.weather_west
  ON summary_all.date = weather_west.date;