-- Project: The Kopi Tide Sales & Weather Analysis
-- Tool: Google BigQuery

-- Note: Replace `case-study-490607` with your own BigQuery project ID

-- Step 1: Combine and standardize weather data

-- WEST STATION
CREATE TABLE singapore_weather_2024.weather_west AS
SELECT * REPLACE (
  SAFE_CAST(highest_30min_rainfall_mm AS FLOAT64) AS highest_30min_rainfall_mm
)
FROM `case-study-490607.singapore_weather_2024.weather_west_apr`

UNION ALL

SELECT *
FROM `case-study-490607.singapore_weather_2024.weather_west_may`;

-- CENTRAL STATION
CREATE TABLE singapore_weather_2024.weather_central AS
SELECT * REPLACE (
  SAFE_CAST(highest_30min_rainfall_mm AS FLOAT64) AS highest_30min_rainfall_mm,
  SAFE_CAST(mean_temp_deg AS FLOAT64) AS mean_temp_deg,
  SAFE_CAST(max_temp_deg AS FLOAT64) AS max_temp_deg,
  SAFE_CAST(min_temp_deg AS FLOAT64) AS min_temp_deg,
  SAFE_CAST(mean_wind_kmh AS FLOAT64) AS mean_wind_kmh,
  SAFE_CAST(max_wind_kmh AS FLOAT64) AS max_wind_kmh
)
FROM `case-study-490607.singapore_weather_2024.weather_central_apr`

UNION ALL

SELECT * REPLACE (
  SAFE_CAST(mean_temp_deg AS FLOAT64) AS mean_temp_deg,
  SAFE_CAST(max_temp_deg AS FLOAT64) AS max_temp_deg,
  SAFE_CAST(min_temp_deg AS FLOAT64) AS min_temp_deg,
  SAFE_CAST(mean_wind_kmh AS FLOAT64) AS mean_wind_kmh,
  SAFE_CAST(max_wind_kmh AS FLOAT64) AS max_wind_kmh
)
FROM `case-study-490607.singapore_weather_2024.weather_central_may`;

-- STANDARDIZE DATE + SELECT REQUIRED COLUMNS
CREATE OR REPLACE TABLE singapore_weather_2024.weather_all AS
SELECT 
  station,
  DATE(year, month, day) AS date,
  rainfall_total_mm,
  highest_30min_rainfall_mm,
  highest_60min_rainfall_mm,
  highest_120min_rainfall_mm,
  mean_temp_deg,
  max_temp_deg,
  min_temp_deg,
  mean_wind_kmh,
  max_wind_kmh
FROM `case-study-490607.singapore_weather_2024.weather_all`;