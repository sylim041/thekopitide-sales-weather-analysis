-- Project: The Kopi Tide Sales & Weather Analysis
-- Tool: Google BigQuery

-- Note: Replace `case-study-490607` with your own BigQuery project ID
-- Step 5: Analysis queries

-- Rainfall vs performance
SELECT
  date,
  store_id,
  rainfall,
  total_customers,
  total_revenue,
  avg_transaction_value
FROM thekopitide_2024.analysis_base
ORDER BY rainfall DESC;

-- Rain vs No Rain customer comparison
SELECT
  CASE 
    WHEN rainfall > 0 THEN 'Rainy'
    ELSE 'No Rain'
  END AS weather_type,
  total_customers
FROM thekopitide_2024.analysis_base
GROUP BY weather_type, total_customers;

-- CBD Rain Impact
WITH cbd_data AS (
  SELECT *
  FROM thekopitide_2024.analysis_base
  WHERE store_id = 'S001'
),
rain_group AS (
  SELECT
    CASE 
      WHEN rainfall > 0 THEN 'Rain'
      ELSE 'No Rain'
    END AS rain_flag,
    AVG(total_revenue) AS avg_sales
  FROM cbd_data
  GROUP BY rain_flag
)
SELECT * FROM rain_group;

-- Peak sales days
SELECT
  date,
  total_revenue
FROM thekopitide_2024.analysis_base
ORDER BY total_revenue DESC;

-- Hourly sales
SELECT
  EXTRACT(HOUR FROM time) AS hour,
  SUM(total_amount) AS total_sales,
  store_id,
  store_name
FROM thekopitide_2024.transactions_all
GROUP BY hour, store_id, store_name
ORDER BY hour;